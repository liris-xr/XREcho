﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

// include required packages
using Curve;
using Tubular;

public class TrajectoryManager : MonoBehaviour
{
    static TrajectoryManager instance;

    public float radius = 0.03f;
    public int nbRadialSegments = 8;
    public bool closed = false;

    [Header("Display")]
    public bool showTrajectories = true;
    public void ToggleTrajectories() { showTrajectories = !showTrajectories; CheckTrajectoriesVisibility(); }
    public bool showControlPoints = true;
    public void ToggleControlPoints() { showControlPoints = !showControlPoints; CheckControlPointsVisibility(); }
    public float sphereSize = 0.1f;

    [Header("Trajectory colors")]
    public int numberOfColors = 3;
    public Color startingColor = Color.HSVToRGB(0f, 0.8f, 1.0f);

    int nbTrajectories;

    GameObject trajectoryObject;
    List<GameObject> trajectories;
    List<CatmullRomCurve> curves;

    List<GameObject> controlPointsObjects;
    List<List<GameObject>> cpSpheres;
    List<List<Vector3>> controlPoints;

    void Awake()
    {
        if (instance)
            Debug.LogError("2 Trajectory Managers: singleton design pattern broken");

        instance = this;
        InitTrajectories();
    }

    public void InitTrajectories()
    {
        nbTrajectories = 0;
        trajectories = new List<GameObject>();
        curves = new List<CatmullRomCurve>();

        controlPointsObjects = new List<GameObject>();
        cpSpheres = new List<List<GameObject>>();
        controlPoints = new List<List<Vector3>>();

        if (trajectoryObject != null)
            Destroy(trajectoryObject);

        trajectoryObject = new GameObject("Trajectories");
        trajectoryObject.transform.parent = transform;
    }

    public static TrajectoryManager GetInstance()
    {
        return instance;
    }

    Color GetNthColor(int n)
    {
        int numerator;
        int denominator;

        // Step 0
        if (n < numberOfColors)
        {
            numerator = n + 1;
            denominator = numberOfColors;
        }
        // Next steps, the number of intervals is multiplied by 2**(step - 1)
        else
        {
            int step = (int)Mathf.Log(n / numberOfColors, 2) + 1;
            int nbIntervals = numberOfColors * (int)Mathf.Pow(2, step - 1);
            numerator = 2 * (n - nbIntervals) + 1;
            denominator = nbIntervals * 2;
        }

        float H, S, V;
        Color.RGBToHSV(startingColor, out H, out S, out V);

        H = ((float)numerator / (float)denominator + H - (1.0f / (float)numberOfColors)) % 1.0f;
        
        return Color.HSVToRGB(H, S, V);
    }

    public int NewTrajectory(List<Vector3> controlPointsList = null)
    {
        GameObject trajectory = new GameObject("Trajectory " + nbTrajectories);
        trajectory.transform.parent = trajectoryObject.transform;
        trajectories.Add(trajectory);
        curves.Add(null);

        trajectory.AddComponent<MeshFilter>();
        MeshRenderer meshRenderer = trajectory.AddComponent<MeshRenderer>();
        meshRenderer.material = new Material(Shader.Find("Unlit/Color"));
        meshRenderer.material.color = GetNthColor(nbTrajectories);

        GameObject controlPointsObject = new GameObject("Control Points");
        controlPointsObject.transform.parent = trajectory.transform;
        controlPointsObjects.Add(controlPointsObject);

        if (controlPointsList == null)
            controlPointsList = new List<Vector3>();

        controlPoints.Add(controlPointsList);
        cpSpheres.Add(new List<GameObject>());

        foreach (Vector3 cp in controlPointsList)
            NewCPSphere(nbTrajectories, cp);

        BuildCurve(nbTrajectories);

        return nbTrajectories++;
    }

    public void AddControlPoint(int i, Vector3 cp)
    {
        controlPoints[i].Add(cp);

        if (controlPoints[i].Count > 1)
            BuildCurve(i);

        NewCPSphere(i, cp);
    }

    void NewCPSphere(int i, Vector3 position)
    {
        GameObject sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        sphere.transform.parent = controlPointsObjects[i].transform;
        sphere.transform.position = position;
        sphere.transform.localScale = new Vector3(sphereSize, sphereSize, sphereSize);

        cpSpheres[i].Add(sphere);
    }

    void ChangeCPSphereSize()
    {
        if (cpSpheres == null)
            return;

        foreach (List<GameObject> listOfSpheres in cpSpheres)
            foreach (GameObject sphere in listOfSpheres)
                sphere.transform.localScale = new Vector3(sphereSize, sphereSize, sphereSize);
    }

    void BuildCurve(int i)
    {
        curves[i] = new CatmullRomCurve(controlPoints[i]);
        BuildTubularMesh(i);
    }

    void BuildTubularMesh(int i)
    {
        // Build tubular mesh with Curve
        int nbTubularSegments = controlPoints[i].Count - 1;

        if (nbTubularSegments < 1)
            return;

        var mesh = Tubular.Tubular.Build(curves[i], nbTubularSegments, radius, nbRadialSegments, closed);

        // visualize mesh
        trajectories[i].GetComponent<MeshFilter>().sharedMesh = mesh;

        CheckTrajectoriesVisibility();
        CheckControlPointsVisibility();
    }

    void RebuildTubularMeshes()
    {
        for (int i = 0; i < nbTrajectories; i++)
            BuildTubularMesh(i);
    }

    void ChangeColors()
    {
        for (int i = 0; i < nbTrajectories; i++)
            trajectories[i].GetComponent<MeshRenderer>().material.color = GetNthColor(i);
    }

    void CheckTrajectoriesVisibility()
    {
        if (trajectories == null)
            return;

        foreach (GameObject trajectory in trajectories)
            trajectory.SetActive(showTrajectories);
    }


    void CheckControlPointsVisibility()
    {
        if (controlPointsObjects == null)
            return;

        foreach (GameObject controlPointsObject in controlPointsObjects)
            controlPointsObject.SetActive(showControlPoints);
    }

    void OnValidate()
    {
        RebuildTubularMeshes();
        ChangeCPSphereSize();
        ChangeColors();
        CheckTrajectoriesVisibility();
        CheckControlPointsVisibility();
    }
}