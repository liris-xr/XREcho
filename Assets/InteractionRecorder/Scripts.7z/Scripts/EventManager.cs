using UnityEngine;
using UnityEngine.Events;

using Valve.VR;
using Valve.VR.InteractionSystem;

public class EventManager : MonoBehaviour
{
    private SteamVR_Action_Boolean headsetOnHead = SteamVR_Input.GetBooleanAction("HeadsetOnHead");
    private SteamVR_Action_Boolean teleporting = SteamVR_Input.GetBooleanAction("Teleport");

    private UnityAction<TeleportMarkerBase> playerUnityAction;

    public void HeadsetOnHead(SteamVR_Action_Boolean fromAction, SteamVR_Input_Sources fromSource)
    {
        recordingManager.LogEvent("HeadsetMounted");
    }
    public void HeadsetOffHead(SteamVR_Action_Boolean fromAction, SteamVR_Input_Sources fromSource)
    {
        recordingManager.LogEvent("HeadsetRemoved");
    }
    /*
    public void OnTeleport(TeleportMarkerBase teleportPoint)
    {
        if (teleportPoint == null)
            return;

        //Teleport to a new scene
        if ( teleportPoint.teleportType == TeleportPoint.TeleportPointType.SwitchToNewScene )
        {
            recordingManager.LogSceneLoad(teleportPoint.switchToScene);
            return;
        }

        recordingManager.LogEvent("Teleport");
        // r�cup�rer position des marqueurs et app�l�s TeleportPlayer � la main?
    }
    public void SceneChange()
    {
        recordingManager.LogEvent("SceneChange");
    }
    */

    private RecordingManager recordingManager;

    private void Start()
    {
        recordingManager = RecordingManager.GetInstance();

        headsetOnHead.AddOnStateDownListener(HeadsetOnHead, SteamVR_Input_Sources.Head);
        headsetOnHead.AddOnStateUpListener(HeadsetOffHead, SteamVR_Input_Sources.Head);
        //teleporting.AddOnStateUpListener(Teleporting, SteamVR_Input_Sources.Any);

        /*
        Teleport.PlayerPre.Listen(playerUnityAction);
        playerUnityAction += OnTeleport;
        */

    }
}
