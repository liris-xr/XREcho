public interface TrackingScript
{
    string GetDataName();
    float[] GetData();
}