using UnityEngine;

public class TrackingAction
{
    public ActionType type;
    public TrackedObject trackedObj;
    public GameObject targetObj;
}