using UnityEngine;
using UnityEngine.Rendering;

using System;
using System.IO;

public class Utils
{
    public static string GetRenderingPipeline()
    {
        if (GraphicsSettings.currentRenderPipeline)
        {
            if (GraphicsSettings.currentRenderPipeline.GetType().ToString().Contains("HighDefinition"))
            {
                return "HDRP";
            }
            else
            {
                return "URP";
            }
        }
        else
        {
            return "Legacy";
        }
    }

    public static bool CreateDirectoryIfNotExists(string folderPath)
    {
        try
        {
            if (!Directory.Exists(folderPath))
                Directory.CreateDirectory(folderPath);
        }
        catch (IOException ex)
        {
            Debug.Log(ex.Message);
            return false;
        }

        return true;
    }


    /*
     * Gets the full path of a game object
     */
    public static string GetGameObjectPath(GameObject obj)
    {
        string path = "/" + obj.name;
        while (obj.transform.parent != null)
        {
            obj = obj.transform.parent.gameObject;
            path = "/" + obj.name + path;
        }
        return path;
    }

    public static long GetTicksSinceDateBegin(DateTime dateTime)
    {
        return (dateTime.Ticks - ExpeRecorderConfig.GetInstance().dateBegin.Ticks); // Ticks are in 1/10th of a microsecond
    }

    public static long GetMicroSecondsSinceDateBegin(DateTime dateTime)
    {
        return (dateTime.Ticks - ExpeRecorderConfig.GetInstance().dateBegin.Ticks) / 10L; // Goes from 1/10th of a microsecond to microseconds
    }

}
